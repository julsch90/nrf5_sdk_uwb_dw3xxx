###############################################################################
#       Murata 2AB nRF52840 Build for DW3000 API + Simple Examples            #
###############################################################################
This README file will describe the following:
-> Setup
-> Compiling the code.
-> Running a Simple Example Executable.
-> Notes on the Hardware Used.

###############################################################################
#                              Setup                                          #
#                        Compiling the code                                   #
#                  Running a Simple Example Executable                        #
###############################################################################

Please refer to instructions for the nRF52840-DK target.
